package com.example.jobshub;


import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class AddActivity extends AppCompatActivity {

    EditText company_name_input, job_title_input, applicant_name_input, email_address_input, contact_number_input, work_experience_input, highest_education_qualification_input;
    Button add_button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add);

        company_name_input = findViewById(R.id.company_name_input);
        job_title_input = findViewById(R.id.job_title_input);
        applicant_name_input = findViewById(R.id.applicant_name_input);
        email_address_input = findViewById(R.id.email_address_input);
        contact_number_input = findViewById(R.id.contact_number_input);
        work_experience_input = findViewById(R.id.work_experience_input);
        highest_education_qualification_input = findViewById(R.id.highest_education_qualification_input);
        add_button = findViewById(R.id.add_button);
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                MyDatabaseHelper myDB = new MyDatabaseHelper(AddActivity.this);
                myDB.addApplication(company_name_input.getText().toString().trim(),
                        job_title_input.getText().toString().trim(),
                        applicant_name_input.getText().toString().trim(),
                        email_address_input.getText().toString().trim(),
                        Integer.valueOf(contact_number_input.getText().toString().trim()),
                        Integer.valueOf(work_experience_input.getText().toString().trim()),
                        highest_education_qualification_input.getText().toString().trim());
            }
        });
    }
}