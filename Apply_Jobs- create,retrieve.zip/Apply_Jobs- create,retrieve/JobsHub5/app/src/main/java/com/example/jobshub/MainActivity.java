package com.example.jobshub;


import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.database.Cursor;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    RecyclerView recyclerView;
    FloatingActionButton add_button;
    ImageView empty_imageview;
    TextView no_data;

    MyDatabaseHelper myDB;
    ArrayList<String> application_id;
    ArrayList<String> company_name;
    ArrayList<String> job_title;
    ArrayList<String> applicant_name;
    ArrayList<String> email_address;
    ArrayList<String> contact_number;
    ArrayList<byte[]> work_experience;
    ArrayList<byte[]> highest_education_qualification;
    CustomAdapter customAdapter;

    @SuppressLint("WrongViewCast")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        recyclerView = findViewById(R.id.recyclerView);
        add_button = findViewById(R.id.add_button);
        empty_imageview = findViewById(R.id.empty_imageview);
        no_data = findViewById(R.id.no_data);
        //FloatingActionButton floatingActionButton = findViewById(R.id.floatingActionButton);

        //navigate from main activity to job application
        add_button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MainActivity.this, AddActivity.class);
                startActivity(intent);
            }
        });

        myDB = new MyDatabaseHelper(MainActivity.this);
        application_id = new ArrayList<>();
        company_name = new ArrayList<>();
        job_title = new ArrayList<>();
        applicant_name = new ArrayList<>();
        email_address = new ArrayList<>();
        contact_number = new ArrayList<>();
        work_experience = new ArrayList<byte[]>();
        highest_education_qualification = new ArrayList<byte[]>();

        storeDataInArrays();

        customAdapter = new CustomAdapter(MainActivity.this,this, application_id, company_name, job_title,
                applicant_name, email_address, contact_number, work_experience, highest_education_qualification);
        recyclerView.setAdapter(customAdapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(MainActivity.this));

    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == 1){
            recreate();
        }
    }

    void storeDataInArrays(){
        Cursor cursor = myDB.readAllData();
        if(cursor.getCount() == 0){
            empty_imageview.setVisibility(View.VISIBLE);
            no_data.setVisibility(View.VISIBLE);
        }else{
            while (cursor.moveToNext()){
                application_id.add(cursor.getString(0));
                company_name.add(cursor.getString(1));
                job_title.add(cursor.getString(2));
                applicant_name.add(cursor.getString(3));
                email_address.add(cursor.getString(4));
                contact_number.add(cursor.getString(5));
                //work_experience.add(cursor.getBlob(6));//*****************************
                //highest_education_qualification.add(cursor.getBlob(7));//*************************************
            }
            empty_imageview.setVisibility(View.GONE);
            no_data.setVisibility(View.GONE);
        }
    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.my_menu, menu);
        return super.onCreateOptionsMenu(menu);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        if(item.getItemId() == R.id.delete_all){
            confirmDialog();
        }
        return super.onOptionsItemSelected(item);
    }

 }