package com.example.jobshub;


import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.LinearLayout;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class CustomAdapter extends RecyclerView.Adapter<CustomAdapter.MyViewHolder> {

    private Context context;
    private Activity activity;
    private ArrayList application_id, company_name, job_title, applicant_name, email_address, contact_number, work_experience, highest_education_qualification;

    CustomAdapter(Activity activity, Context context, ArrayList application_id, ArrayList company_name, ArrayList job_title,
                  ArrayList applicant_name,  ArrayList email_address,  ArrayList contact_number,  ArrayList work_experience,
                  ArrayList highest_education_qualification){
        this.activity = activity;
        this.context = context;
        this.application_id = application_id;
        this.company_name = company_name;
        this.job_title = job_title;
        this.applicant_name = applicant_name;
        this.email_address = email_address;
        this.contact_number = contact_number;
        this.work_experience = work_experience;
        this.highest_education_qualification = highest_education_qualification;
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.my_row, parent, false);
        return new MyViewHolder(view);
    }

    @RequiresApi(api = Build.VERSION_CODES.M)
    @Override
    public void onBindViewHolder(@NonNull final MyViewHolder holder, @SuppressLint("RecyclerView") final int position) {
        holder.application_id_txt.setText(String.valueOf(application_id.get(position)));
        holder.company_name_txt.setText(String.valueOf(company_name.get(position)));
        holder.job_title_txt.setText(String.valueOf(job_title.get(position)));
        //holder.applicant_name_txt.setText(String.valueOf(applicant_name.get(position)));
        //holder.email_address_txt.setText(String.valueOf(email_address.get(position)));
        //holder.contact_number_txt.setText(String.valueOf(contact_number.get(position)));
        //holder.work_experience_txt.setText(String.valueOf(work_experience.get(position)));
        //holder.highest_education_qualification_txt.setText(String.valueOf(highest_education_qualification.get(position)));
        //Recyclerview onClickListener
        holder.mainLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(context, UpdateActivity.class);
                intent.putExtra("id", String.valueOf(application_id.get(position)));
                intent.putExtra("company_name", String.valueOf(company_name.get(position)));
                intent.putExtra("job_title", String.valueOf(job_title.get(position)));
                intent.putExtra("applicant_name", String.valueOf(applicant_name.get(position)));
                intent.putExtra("email_address", String.valueOf(email_address.get(position)));
                intent.putExtra("contact_number", String.valueOf(contact_number.get(position)));
                //intent.putExtra("work_experience", String.valueOf(work_experience.get(position)));
                //intent.putExtra("highest_education_qualification", String.valueOf(highest_education_qualification.get(position)));
                activity.startActivityForResult(intent, 1);
            }
        });


    }

    @Override
    public int getItemCount() {
        return application_id.size();
    }

    class MyViewHolder extends RecyclerView.ViewHolder {

        TextView application_id_txt, company_name_txt, job_title_txt,
                applicant_name_txt, email_address_txt, contact_number_txt, work_experience_txt, highest_education_qualification_txt ;
        LinearLayout mainLayout;

        MyViewHolder(@NonNull View itemView) {
            super(itemView);
            application_id_txt = itemView.findViewById(R.id.application_id_txt);
            company_name_txt = itemView.findViewById(R.id.company_name_txt);
            job_title_txt = itemView.findViewById(R.id.job_title_txt);
            /*applicant_name_txt = itemView.findViewById(R.id.applicant_name_txt);
            email_address_txt = itemView.findViewById(R.id.email_address_txt);
            contact_number_txt = itemView.findViewById(R.id.contact_number_txt);
            work_experience_txt = itemView.findViewById(R.id.work_experience_txt);
            highest_education_qualification_txt = itemView.findViewById(R.id.highest_education_qualification_txt);*/
            mainLayout = itemView.findViewById(R.id.mainLayout);
            //Animate Recyclerview
            Animation translate_anim = AnimationUtils.loadAnimation(context, R.anim.translate_anim);
            mainLayout.setAnimation(translate_anim);
        }

    }

}

