package com.example.jobshub;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.ImageView;

public class HomeActivity extends AppCompatActivity {
    ImageView img_js;
    ImageView img_jp;
    Button btn_js;
    Button btn_jp;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);

        img_js = findViewById(R.id.image_JS);
        img_jp = findViewById(R.id.image_JP);
        btn_js = findViewById(R.id.button_JS);
        btn_jp = findViewById(R.id.button_JP);

        btn_js.setOnClickListener(v -> btnJobSeeker());
       // btn_jp.setOnClickListener(v -> btnJobprovider());
    }

    public void btnJobSeeker(){
        Intent jobSeekerIntent = new Intent(HomeActivity.this,MainActivity.class);
        startActivity(jobSeekerIntent);
    }

   /* private void btnJobprovider() {
        Intent jobProviderIntent = new Intent(HomeActivity.this,LoginActivity.class);

    }*/
}
